const fs = require('fs')
const url = require('url');

let charset = "utf8"

let filePath = "C:/Users/tengfa/Desktop/livedemo00.template-help.com.har"

let saveDir = "./web"

fs.readFile(filePath, charset, (err, data) => {
    if (err) {
        console.log(err)
    }

    let harJson = JSON.parse(data)
    parseMain(harJson)
});

function parseMain(harJson) {
    console.log("download resources count:" + harJson.log.entries.length);
    let down_files = {
        html: [],
        css: [],
        js: [],
        imgs: [],
        others: []
    };
    let entries = harJson.log.entries
    entries.forEach((item) => {
        if (item.response) {

            let itemUri = url.parse(item.request.url)
            let type = item.response.headers.filter((head) => head.name == "content-type")

            let fileName = itemUri.pathname.substr(itemUri.pathname.lastIndexOf("/") + 1)

            let saveObj = {
                fielname: fileName,
                url: item.request.url,
                content: item.response.content
            }
            // console.log(typeof type[0])
            if (type[0] && type[0].value.indexOf("html") > -1) {
                down_files.html.push(saveObj)
            } else if (type[0] && type[0].value.indexOf("css") > -1) {
                down_files.css.push(saveObj)
            } else if (type[0] && type[0].value.indexOf("javascript") > -1) {
                down_files.js.push(saveObj)
            } else if (type[0] && type[0].value.indexOf("image") > -1) {
                down_files.imgs.push(saveObj)
            } else {
                down_files.others.push(saveObj)
            }
        }
    });
    saveFile(down_files);
}

function saveFile(downlist) {
    // console.log(downlist)
    let staticPath = saveDir + "/static"
    if (!fs.existsSync(saveDir)) {
        fs.mkdirSync(saveDir);
        fs.mkdirSync(staticPath);
    }

    for (let key in downlist) {
        let currentPath = key == "html" ? staticPath + "/" : staticPath + "/" + key + "/"
        let currentArr = downlist[key];

        if (key != "html" && !fs.existsSync(currentPath)) { fs.mkdirSync(currentPath); }

        for (let i = 0; i < currentArr.length; i++) {
            let saveFile = currentArr[i];
            if (key == "imgs") {
                let dataBuffer = new Buffer(saveFile.content.text, 'base64');
                fs.writeFileSync(currentPath + saveFile.fielname, dataBuffer)
            } else {
                fs.writeFileSync(currentPath + saveFile.fielname, saveFile.content.text)
            }
        }

    }
}

